# My First AI

My First AI is an independently implemented decoder-only Transformer project. The hosted app contains a small byte-level Transformer with its own weights, training loop, persisted checkpoint, inference path, and developer API. The repository also contains a separate PyTorch v5 training path for real CUDA/GPU training.

## Project structure

- `src/` — React dashboard
- `backend/` — hosted model, training, persistence, inference, and developer API
- `training/` — PyTorch v5 BPE tokenizer, model, dataset preparation, GPU trainer, evaluator
- `tests/tests.txt` — user-visible end-to-end test suite
- `colab/` — Google Colab launcher for CUDA training

## Hosted model: v4-byte

- Decoder-only Transformer
- UTF-8 byte-level tokenizer
- Vocabulary: 256
- Context: 96
- Model width: 32
- Layers: 3
- FFN width: 64
- Exact trainable parameters: 44,288
- Full-parameter reverse-mode backpropagation
- Mini-batch Adam updates
- Persisted model checkpoint

## GPU model: v5-bpe

The `training/` package is the larger PyTorch path intended for a CUDA machine such as a Colab T4.

- BPE over UTF-8 bytes
- Target vocabulary: 1,024
- Context: 256
- Model width: 64
- Decoder blocks: 4
- FFN width: 256
- Exact parameters at vocab 1,024: 345,088
- AdamW
- Gradient clipping
- Float16 autocast on CUDA
- Validation loss and perplexity
- Periodic and resumable checkpoints

## GPU training

Prepare a text corpus:

```bash
python training/prepare_data.py --input data/train.txt --out data/processed --vocab-size 1024
```

Train on CUDA:

```bash
python training/train.py --data-dir data/processed --steps 1000 --batch-size 32 --lr 0.0003 --seed 42 --out checkpoints/my-first-ai-v5-bpe.pt
```

Evaluate:

```bash
python training/evaluate.py --checkpoint checkpoints/my-first-ai-v5-bpe.pt --data-dir data/processed
```

For Google Colab, open `colab/train_gpu.ipynb`, select a GPU runtime, clone this repository, install `training/requirements.txt`, and run the preparation/training cells.

## Developer API

The hosted app exposes a public generation endpoint at `/api/v1/generate`. Developers create an API key in the dashboard and authenticate requests with `Authorization: Bearer <key>` or the `api_key` request field.

## Important

No model provider API is required by the custom training path. The v5 trainer trains the Transformer weights directly with PyTorch. Large-scale training beyond this small model requires substantially more compute and engineering.
